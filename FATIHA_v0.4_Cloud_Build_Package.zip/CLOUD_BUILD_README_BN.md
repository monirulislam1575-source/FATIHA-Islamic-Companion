# FATIHA v0.4 — ক্লাউড Build চালানোর নির্দেশনা

এই প্যাকেজে GitHub Actions workflow যোগ করা হয়েছে। GitHub-এর Ubuntu runner-এ Flutter stable, Java 17 এবং Android build tools ব্যবহার করে নিচের ধাপগুলো চালাবে:

1. `flutter pub get`
2. `flutter analyze`
3. `flutter test --reporter expanded`
4. `flutter build apk --debug`
5. সফল হলে `FATIHA-v0.4-debug-apk` নামে APK artifact সংরক্ষণ

## কীভাবে ক্লাউড Build চালাবেন

1. GitHub-এ একটি নতুন repository তৈরি করুন (Private রাখা যায়)।
2. এই ZIP extract করে এর ভেতরের সব ফাইল repository-তে upload/commit করুন। `.github/workflows/android.yml` ফাইলটি যেন repository root-এ থাকে।
3. GitHub repository-এর **Actions** tab খুলুন।
4. **FATIHA v0.4 Android CI** workflow নির্বাচন করে **Run workflow** চাপুন। প্রথমবার GitHub Actions অনুমোদন/সক্রিয় করতে বলতে পারে।
5. workflow শেষ হলে সফল run খুলে **Artifacts** থেকে `FATIHA-v0.4-debug-apk` ডাউনলোড করুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা

- এই চ্যাট থেকে আপনার GitHub account-এ repository তৈরি বা workflow চালু করার অনুমতি/সংযোগ নেই; তাই ক্লাউড রান এখনো শুরু হয়নি।
- Workflow-এর APK Build সফল হলেও সেটি কেবল compile/build প্রমাণ করবে। বাস্তব Android ফোনে অডিও, SQLite migration এবং Add/Edit/Delete আচরণ আলাদাভাবে যাচাই করতে হবে।
- `flutter analyze` বা test ব্যর্থ হলে Actions log এখানে পাঠান; সেই অনুযায়ী v0.4 সোর্স সংশোধন করা যাবে।
- Release/Play Store APK-এর জন্য আলাদা private signing keystore প্রয়োজন; এই workflow debug APK তৈরি করে।
