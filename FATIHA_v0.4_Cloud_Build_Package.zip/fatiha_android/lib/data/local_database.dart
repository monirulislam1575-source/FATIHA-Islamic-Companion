import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class LocalDatabase {
  LocalDatabase._();
  static final LocalDatabase instance = LocalDatabase._();
  static const _name = 'fatiha_companion.db';
  static const _version = 2;
  Database? _db;
  Future<Database>? _opening;

  Future<Database> get database async {
    if (_db != null) return _db!;
    // Share one in-flight open operation when multiple screens request the DB.
    return _opening ??= _open();
  }

  Future<Database> _open() async {
    try {
      final base = await getDatabasesPath();
      final db = await openDatabase(p.join(base, _name), version: _version,
      onCreate: (db, version) async {
        await db.execute('''CREATE TABLE islamic_content (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          category TEXT NOT NULL,
          title_bn TEXT NOT NULL,
          arabic_text TEXT NOT NULL DEFAULT '',
          transliteration_bn TEXT NOT NULL DEFAULT '',
          meaning_bn TEXT NOT NULL DEFAULT '',
          source_reference TEXT NOT NULL DEFAULT '',
          authenticity_note TEXT NOT NULL DEFAULT '',
          is_favorite INTEGER NOT NULL DEFAULT 0,
          audio_url TEXT NOT NULL DEFAULT '',
          audio_local_path TEXT NOT NULL DEFAULT '',
          audio_license_note TEXT NOT NULL DEFAULT ''
        )''');
        await db.execute('CREATE INDEX content_category_idx ON islamic_content(category)');
        await db.execute('CREATE INDEX content_favorite_idx ON islamic_content(is_favorite)');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute("ALTER TABLE islamic_content ADD COLUMN audio_url TEXT NOT NULL DEFAULT ''");
          await db.execute("ALTER TABLE islamic_content ADD COLUMN audio_local_path TEXT NOT NULL DEFAULT ''");
          await db.execute("ALTER TABLE islamic_content ADD COLUMN audio_license_note TEXT NOT NULL DEFAULT ''");
        }
      },
      );
      _db = db;
      return db;
    } catch (_) {
      _opening = null; // Permit a later retry after a failed open.
      rethrow;
    }
  }
}
