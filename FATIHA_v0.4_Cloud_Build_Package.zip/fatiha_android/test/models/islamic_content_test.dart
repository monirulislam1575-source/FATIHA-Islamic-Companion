import 'package:flutter_test/flutter_test.dart';
import 'package:fatiha_islamic_companion/models/islamic_content.dart';

void main() {
  group('IslamicContent', () {
    test('round-trips all v0.4 fields through SQLite map format', () {
      const original = IslamicContent(
        id: 7,
        category: 'দোয়া',
        titleBn: 'ঘুমের দোয়া',
        arabicText: 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا',
        transliterationBn: 'বিসমিকা আল্লাহুম্মা...',
        meaningBn: 'হে আল্লাহ, আপনার নামে...',
        sourceReference: 'সহিহ বুখারি',
        authenticityNote: 'সহিহ',
        isFavorite: true,
        audioUrl: 'https://example.org/audio.mp3',
        audioLocalPath: '/storage/emulated/0/Music/dua.mp3',
        audioLicenseNote: 'ব্যবহারের অনুমতি যাচাই করা হয়েছে',
      );

      final restored = IslamicContent.fromMap(original.toMap());
      expect(restored.id, original.id);
      expect(restored.category, original.category);
      expect(restored.titleBn, original.titleBn);
      expect(restored.arabicText, original.arabicText);
      expect(restored.transliterationBn, original.transliterationBn);
      expect(restored.meaningBn, original.meaningBn);
      expect(restored.sourceReference, original.sourceReference);
      expect(restored.authenticityNote, original.authenticityNote);
      expect(restored.isFavorite, isTrue);
      expect(restored.audioUrl, original.audioUrl);
      expect(restored.audioLocalPath, original.audioLocalPath);
      expect(restored.audioLicenseNote, original.audioLicenseNote);
    });

    test('reads legacy v1 maps with absent v0.4 audio fields', () {
      final restored = IslamicContent.fromMap(<String, Object?>{
        'id': 1,
        'category': 'দোয়া',
        'title_bn': 'পরীক্ষামূলক',
        'is_favorite': 0,
      });

      expect(restored.audioUrl, isEmpty);
      expect(restored.audioLocalPath, isEmpty);
      expect(restored.audioLicenseNote, isEmpty);
      expect(restored.isFavorite, isFalse);
    });
  });
}
