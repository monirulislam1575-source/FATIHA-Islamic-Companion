# FATIHA Islamic Companion v0.4 — Android scaffold and verification status

This package now includes a native Android host scaffold (`android/`) for Flutter.
It targets package `com.fatiha.islamiccompanion`, version `0.4.0+4`, Android API 23+
(minSdk), and declares INTERNET permission for remote audio URLs.

## Build environment status

The preparation container has OpenJDK 21, but does **not** have Flutter, Dart,
Gradle, Android SDK, or ADB installed/configured. Therefore dependency resolution,
Dart analysis, Android compilation, emulator/device launch, SQLite migration runtime,
audio playback, and APK creation have **not** been executed here. The scaffold is
source-prepared, not build-verified. No APK is included.

## Build and test on a Flutter-enabled machine

Use a machine with a current stable Flutter SDK, Android SDK/platform tools, and
Android SDK licenses accepted. Android Gradle Plugin is pinned to 8.9.1 and Kotlin
plugin to 2.1.0; The wrapper distribution is pinned to Gradle 8.11.1; the wrapper launcher JAR/scripts are not bundled in this environment, so generate them with `gradle wrapper --gradle-version 8.11.1` or regenerate the Android platform using the installed Flutter SDK before building. The source declares Flutter >=3.27.0 because it uses `Color.withValues`.

```bash
cd fatiha_android
flutter doctor -v
# If wrapper scripts are absent, run: gradle wrapper --gradle-version 8.11.1
flutter pub get
dart format --output=none --set-exit-if-changed lib
flutter analyze
flutter test
flutter build apk --debug
# With an emulator/device connected:
flutter run
# After smoke tests:
flutter build apk --release
```

If the local Flutter release requires a newer Android Gradle Plugin/Kotlin/Gradle
combination, use the versions recommended by `flutter doctor` / that Flutter
release's generated template and keep Java 17 compatibility.

## Required runtime acceptance checks

- Fresh install creates SQLite schema v2.
- A copied v1 database upgrades to v2 and preserves pre-existing rows.
- Add a record, restart app, and confirm persistence.
- Edit a record and confirm updated values persist.
- Delete a record and confirm it disappears.
- Toggle favorite and verify state after reload.
- Play a permitted local audio file and a permitted HTTPS URL; test stop/completion/error.
- Test airplane/offline mode, malformed URL, missing local file, and app background/foreground.

## Release safeguards

The Gradle release build currently uses the debug signing config for local testing only.
Do not publish this APK. Configure a private release keystore and verify content/audio
rights before Play Store distribution. No religious content has been fabricated or
pre-seeded; entries must be checked against reliable sources before publication.
