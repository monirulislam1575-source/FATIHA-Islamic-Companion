# FATIHA Islamic Companion — Android source v0.4

## Release 0.4.0+4

This is a Flutter source-code release built on the saved v0.3 project. It preserves the existing emerald / ivory / gold theme and five-section navigation.

### Added in v0.4
- SQLite schema migration from database version 1 to version 2; existing v0.3 installations retain their saved content and gain audio metadata columns.
- Audio metadata per content item: remote audio URL, local device file path, and a license/permission note.
- Audio playback for a configured local audio file or remote URL using `audioplayers`.
- Content management UI: add, edit, and delete dua/amal entries.
- Existing search, category filtering, favorites, and bookmarks retained.
- App package version updated to `0.4.0+4`.

### Important content and audio safeguards
- No Qur'an, hadith, dua, translation, or prescribed repetition has been fabricated or pre-seeded. The local content database remains empty until a human adds source-verified material.
- Audio playback only works after a user/admin supplies a valid local file path or URL. This release does not yet implement an audio download/cache manager or a cloud admin panel.
- Add audio only when its usage rights permit distribution; record the permission/license in the provided field.

### Build status and how to run
This package contains Flutter source code, not a compiled APK. Flutter and Dart SDKs were not available in the build environment, so a Flutter compile or Android-device test could not be performed here. Run these commands on a machine with Flutter installed:

```bash
cd fatiha_android
flutter pub get
flutter analyze
flutter test
flutter run
```

### Main changed files
- `lib/models/islamic_content.dart` — added audio metadata fields.
- `lib/data/local_database.dart` — SQLite v1-to-v2 migration.
- `lib/repositories/content_repository.dart` — update and delete operations.
- `lib/screens/dua_amal_screen.dart` — add/edit/delete UI and audio playback controls.
- `pubspec.yaml` — `audioplayers` dependency and version `0.4.0+4`.

### Not included yet
Cloud-based admin CMS, cloud synchronization, background audio downloads/offline cache management, verified starter content, prayer-time calculations, Qibla sensor calibration, and APK signing/build pipeline.
