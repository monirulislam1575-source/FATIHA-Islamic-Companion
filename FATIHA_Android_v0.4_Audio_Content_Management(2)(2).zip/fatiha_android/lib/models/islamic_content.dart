/// Local, source-traceable Islamic content model.
/// Religious text is intentionally not seeded until it has been reviewed.
class IslamicContent {
  final int? id;
  final String category;
  final String titleBn;
  final String arabicText;
  final String transliterationBn;
  final String meaningBn;
  final String sourceReference;
  final String authenticityNote;
  final bool isFavorite;
  final String audioUrl;
  final String audioLocalPath;
  final String audioLicenseNote;

  const IslamicContent({
    this.id,
    required this.category,
    required this.titleBn,
    this.arabicText = '',
    this.transliterationBn = '',
    this.meaningBn = '',
    this.sourceReference = '',
    this.authenticityNote = '',
    this.isFavorite = false,
    this.audioUrl = '',
    this.audioLocalPath = '',
    this.audioLicenseNote = '',
  });

  Map<String, Object?> toMap() => {
    'id': id, 'category': category, 'title_bn': titleBn,
    'arabic_text': arabicText, 'transliteration_bn': transliterationBn,
    'meaning_bn': meaningBn, 'source_reference': sourceReference,
    'authenticity_note': authenticityNote, 'is_favorite': isFavorite ? 1 : 0,
    'audio_url': audioUrl, 'audio_local_path': audioLocalPath,
    'audio_license_note': audioLicenseNote,
  };

  factory IslamicContent.fromMap(Map<String, Object?> map) => IslamicContent(
    id: map['id'] as int?, category: map['category'] as String,
    titleBn: map['title_bn'] as String,
    arabicText: map['arabic_text'] as String? ?? '',
    transliterationBn: map['transliteration_bn'] as String? ?? '',
    meaningBn: map['meaning_bn'] as String? ?? '',
    sourceReference: map['source_reference'] as String? ?? '',
    authenticityNote: map['authenticity_note'] as String? ?? '',
    isFavorite: (map['is_favorite'] as int? ?? 0) == 1,
    audioUrl: map['audio_url'] as String? ?? '',
    audioLocalPath: map['audio_local_path'] as String? ?? '',
    audioLicenseNote: map['audio_license_note'] as String? ?? '',
  );
}
