import '../data/local_database.dart';
import '../models/islamic_content.dart';

class ContentRepository {
  ContentRepository({LocalDatabase? database}) : _local = database ?? LocalDatabase.instance;
  final LocalDatabase _local;

  Future<int> add(IslamicContent content) async {
    final db = await _local.database;
    final values = content.toMap()..remove('id');
    return db.insert('islamic_content', values);
  }

  Future<void> update(IslamicContent content) async {
    if (content.id == null) throw ArgumentError('Content id is required for update');
    final db = await _local.database;
    final values = content.toMap()..remove('id');
    await db.update('islamic_content', values, where: 'id = ?', whereArgs: [content.id]);
  }

  Future<void> delete(int id) async {
    final db = await _local.database;
    await db.delete('islamic_content', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<IslamicContent>> all({String? category, String? search}) async {
    final db = await _local.database;
    final clauses = <String>[];
    final args = <Object?>[];
    if (category != null) { clauses.add('category = ?'); args.add(category); }
    if (search != null && search.trim().isNotEmpty) {
      clauses.add('(title_bn LIKE ? OR meaning_bn LIKE ? OR category LIKE ?)');
      final q = '%${search.trim()}%'; args.addAll([q, q, q]);
    }
    final rows = await db.query('islamic_content',
      where: clauses.isEmpty ? null : clauses.join(' AND '),
      whereArgs: args.isEmpty ? null : args,
      orderBy: 'title_bn COLLATE NOCASE');
    return rows.map(IslamicContent.fromMap).toList();
  }

  Future<List<IslamicContent>> favorites() async {
    final db = await _local.database;
    final rows = await db.query('islamic_content', where: 'is_favorite = 1', orderBy: 'title_bn COLLATE NOCASE');
    return rows.map(IslamicContent.fromMap).toList();
  }

  Future<void> setFavorite(int id, bool value) async {
    final db = await _local.database;
    await db.update('islamic_content', {'is_favorite': value ? 1 : 0}, where: 'id = ?', whereArgs: [id]);
  }
}
