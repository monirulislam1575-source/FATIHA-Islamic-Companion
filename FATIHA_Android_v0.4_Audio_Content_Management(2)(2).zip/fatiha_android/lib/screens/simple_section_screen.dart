import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class SimpleSectionScreen extends StatelessWidget {
  final String title;
  final String subtitle;
  const SimpleSectionScreen({super.key, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.auto_awesome, size: 48, color: FatihaColors.gold),
          const SizedBox(height: 14),
          Text(title, style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: FatihaColors.emerald, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
          const SizedBox(height: 8),
          Text(subtitle, style: const TextStyle(color: FatihaColors.muted), textAlign: TextAlign.center),
          const SizedBox(height: 18),
          const Text('এই বিভাগটি পরবর্তী ডেভেলপমেন্ট ধাপে যুক্ত করা হবে।', textAlign: TextAlign.center),
        ]),
      ),
    ),
  );
}
