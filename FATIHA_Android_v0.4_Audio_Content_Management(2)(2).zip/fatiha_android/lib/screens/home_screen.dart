import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'simple_section_screen.dart';
import 'dua_amal_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          children: [
            Text(FatihaBrand.bengaliName, style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
            Text('FATIHA Islamic Companion', style: TextStyle(fontSize: 11, letterSpacing: 0.4)),
          ],
        ),
        actions: [
          IconButton(tooltip: 'নোটিফিকেশন', onPressed: () => _open(context, 'নোটিফিকেশন', 'আপনার স্মরণিকা এখানে দেখা যাবে।'), icon: const Icon(Icons.notifications_none)),
          IconButton(tooltip: 'সেটিংস', onPressed: () => _open(context, 'সেটিংস', 'থিম, ভাষা ও অন্যান্য পছন্দ এখানে থাকবে।'), icon: const Icon(Icons.settings_outlined)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          const _WelcomeCard(),
          const SizedBox(height: 14),
          const _PrayerSummaryCard(),
          const SizedBox(height: 20),
          Text('দ্রুত প্রবেশ', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold, color: FatihaColors.ink)),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 3,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 0.94,
            children: const [
              _QuickTile(icon: Icons.access_time_filled, title: 'নামাজের\nসময়', subtitle: 'সময় দেখুন'),
              _QuickTile(icon: Icons.volunteer_activism, title: 'দোয়া ও\nআমল', subtitle: 'দৈনিক স্মরণ', onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DuaAmalScreen()))),
              _QuickTile(icon: Icons.menu_book, title: 'কুরআন\nপাঠ', subtitle: 'সূরা ও আয়াত'),
              _QuickTile(icon: Icons.fingerprint, title: 'তাসবিহ\nগণনা', subtitle: 'জিকির গণনা'),
              _QuickTile(icon: Icons.explore, title: 'কিবলা\nকম্পাস', subtitle: 'দিক নির্ণয়'),
              _QuickTile(icon: Icons.shield_outlined, title: 'সুরক্ষা ও\nনিরাপত্তা', subtitle: 'নির্বাচিত দোয়া'),
              _QuickTile(icon: Icons.mosque, title: 'বিশেষ\nনামাজ', subtitle: 'নির্দেশনা'),
              _QuickTile(icon: Icons.menu_book_outlined, title: 'হাদিস ও\nউপদেশ', subtitle: 'জ্ঞান অর্জন'),
              _QuickTile(icon: Icons.tune, title: 'সেটিংস', subtitle: 'নিজের মতো সাজান'),
            ],
          ),
          const SizedBox(height: 18),
          const _DailyVerseCard(),
          const SizedBox(height: 10),
          Text('প্রাথমিক ডেমো: নামাজের সময়, সেহরি-ইফতার ও অন্যান্য লাইভ তথ্য এখনো সংযুক্ত নয়।',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(color: FatihaColors.muted),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  static void _open(BuildContext context, String title, String subtitle) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => SimpleSectionScreen(title: title, subtitle: subtitle)));
  }
}

class _WelcomeCard extends StatelessWidget {
  const _WelcomeCard();
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(22),
      gradient: const LinearGradient(colors: [FatihaColors.emerald, FatihaColors.forest], begin: Alignment.topLeft, end: Alignment.bottomRight),
    ),
    child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('السَّلَامُ عَلَيْكُمْ', style: TextStyle(color: FatihaColors.gold, fontSize: 20, fontWeight: FontWeight.w600)),
      SizedBox(height: 8),
      Text('আসসালামু আলাইকুম', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)),
      SizedBox(height: 5),
      Text('আল্লাহর স্মরণে, শান্তির পথে', style: TextStyle(color: Colors.white70, fontSize: 14)),
    ]),
  );
}

class _PrayerSummaryCard extends StatelessWidget {
  const _PrayerSummaryCard();
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [Icon(Icons.location_on_outlined, color: FatihaColors.forest), SizedBox(width: 6), Text('অবস্থান: ঢাকা, বাংলাদেশ', style: TextStyle(fontWeight: FontWeight.w600)), Spacer(), Icon(Icons.calendar_today_outlined, size: 17, color: FatihaColors.muted)]),
        const SizedBox(height: 14),
        const Text('পরবর্তী নামাজ', style: TextStyle(color: FatihaColors.muted)),
        const SizedBox(height: 3),
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          const Text('ইশা', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: FatihaColors.emerald)),
          const Spacer(),
          Text('সময় সংযুক্ত করা হবে', style: TextStyle(color: FatihaColors.muted, fontSize: 12)),
        ]),
        const SizedBox(height: 12),
        const Divider(height: 1),
        const SizedBox(height: 10),
        const Row(children: [Icon(Icons.wb_twilight, color: FatihaColors.gold), SizedBox(width: 8), Text('নামাজের সময়সূচি যুক্ত করার প্রস্তুতি চলছে', style: TextStyle(fontSize: 12))]),
      ]),
    ),
  );
}

class _QuickTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;
  const _QuickTile({required this.icon, required this.title, required this.subtitle, this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(18),
    onTap: onTap ?? () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SimpleSectionScreen(title: title.replaceAll('\n', ' '), subtitle: subtitle))),
    child: Ink(
      decoration: BoxDecoration(color: FatihaColors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: FatihaColors.mist), boxShadow: const [BoxShadow(color: Color(0x10000000), blurRadius: 5, offset: Offset(0, 2))]),
      child: Padding(padding: const EdgeInsets.all(8), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: FatihaColors.forest, size: 30),
        const SizedBox(height: 7),
        Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold, height: 1.15, color: FatihaColors.ink)),
        const SizedBox(height: 3),
        Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, color: FatihaColors.muted)),
      ]),),
    ),
  );
}

class _DailyVerseCard extends StatelessWidget {
  const _DailyVerseCard();
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: FatihaColors.mist, borderRadius: BorderRadius.circular(20), border: Border.all(color: FatihaColors.gold.withValues(alpha: 0.65))),
    child: const Column(children: [
      Text('رَبِّ زِدْنِي عِلْمًا', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, color: FatihaColors.emerald, fontWeight: FontWeight.w600)),
      SizedBox(height: 7),
      Text('হে আমার রব! আমার জ্ঞান বৃদ্ধি করে দিন।', textAlign: TextAlign.center, style: TextStyle(fontSize: 14, color: FatihaColors.ink)),
      SizedBox(height: 5),
      Text('— সূরা ত্বা-হা, ২০:১১৪', style: TextStyle(fontSize: 11, color: FatihaColors.muted)),
    ]),
  );
}
