import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'home_screen.dart';
import 'simple_section_screen.dart';
import 'dua_amal_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _selectedIndex = 0;

  static const _titles = ['হোম', 'পাঠ', 'পছন্দ', 'সূচি', 'আরও'];

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomeScreen(),
      const SimpleSectionScreen(title: 'কুরআন ও পাঠ', subtitle: 'কুরআন, সূরা ও নির্বাচিত আয়াত'),
      const DuaAmalScreen(favoritesOnly: true),
      const SimpleSectionScreen(title: 'দৈনিক সূচি', subtitle: 'নামাজের সময় ও দৈনিক স্মরণিকা'),
      const SimpleSectionScreen(title: 'আরও', subtitle: 'সেটিংস, ভাষা, অডিও ও অ্যাপ পরিচিতি'),
    ];

    return Scaffold(
      body: IndexedStack(index: _selectedIndex, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) => setState(() => _selectedIndex = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'হোম'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'পাঠ'),
          NavigationDestination(icon: Icon(Icons.star_border), selectedIcon: Icon(Icons.star), label: 'পছন্দ'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'সূচি'),
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), selectedIcon: Icon(Icons.grid_view), label: 'আরও'),
        ],
      ),
    );
  }
}
