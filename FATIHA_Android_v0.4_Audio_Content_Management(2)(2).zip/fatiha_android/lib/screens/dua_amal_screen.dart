import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

import '../models/islamic_content.dart';
import '../repositories/content_repository.dart';
import '../theme/app_theme.dart';

class DuaAmalScreen extends StatefulWidget {
  const DuaAmalScreen({super.key, this.favoritesOnly = false});
  final bool favoritesOnly;
  @override
  State<DuaAmalScreen> createState() => _DuaAmalScreenState();
}

class _DuaAmalScreenState extends State<DuaAmalScreen> {
  final _repo = ContentRepository();
  final _search = TextEditingController();
  final _player = AudioPlayer();
  String? _category;
  int? _playingId;

  Future<List<IslamicContent>> _load() => widget.favoritesOnly
      ? _repo.favorites()
      : _repo.all(category: _category, search: _search.text);

  static const _categories = [
    ('সকাল', 'সকাল'), ('সন্ধ্যা', 'সন্ধ্যা'), ('ঘুমের আগে', 'ঘুমের আগে'),
    ('নামাজের পর', 'নামাজের পর'),
  ];

  @override
  void initState() {
    super.initState();
    _player.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playingId = null);
    });
  }

  @override
  void dispose() {
    _search.dispose();
    _player.dispose();
    super.dispose();
  }

  Future<void> _play(IslamicContent item) async {
    try {
      if (item.audioLocalPath.isNotEmpty && await File(item.audioLocalPath).exists()) {
        await _player.play(DeviceFileSource(item.audioLocalPath));
      } else if (item.audioUrl.isNotEmpty) {
        await _player.play(UrlSource(item.audioUrl));
      } else {
        _message('এই কন্টেন্টের জন্য এখনো অডিও যোগ করা হয়নি।');
        return;
      }
      if (mounted) setState(() => _playingId = item.id);
    } catch (_) {
      _message('অডিও চালানো যায়নি। ফাইল বা ইন্টারনেট সংযোগ পরীক্ষা করুন।');
    }
  }

  void _message(String value) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  Future<void> _edit({IslamicContent? item}) async {
    final result = await showDialog<IslamicContent>(
      context: context,
      builder: (_) => _ContentEditor(item: item),
    );
    if (result == null) return;
    if (item == null) {
      await _repo.add(result);
    } else {
      await _repo.update(result);
    }
    if (mounted) setState(() {});
  }

  Future<void> _delete(IslamicContent item) async {
    final ok = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('কন্টেন্ট মুছবেন?'),
      content: Text('“${item.titleBn}” মুছে যাবে।'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('বাতিল')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('মুছুন'))],
    ));
    if (ok == true && item.id != null) {
      await _repo.delete(item.id!);
      if (mounted) setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.favoritesOnly ? 'পছন্দের দোয়া ও আমল' : 'দোয়া ও আমল')),
    floatingActionButton: widget.favoritesOnly ? null : FloatingActionButton.extended(
      onPressed: () => _edit(), icon: const Icon(Icons.add), label: const Text('কন্টেন্ট যোগ করুন')),
    body: Column(children: [
      if (!widget.favoritesOnly) Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
        child: TextField(controller: _search, onChanged: (_) => setState(() {}),
          decoration: InputDecoration(hintText: 'দোয়া বা আমল খুঁজুন', prefixIcon: const Icon(Icons.search),
            filled: true, fillColor: FatihaColors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
      ),
      if (!widget.favoritesOnly) SizedBox(height: 54, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12),
        children: [_chip('সব', null), ..._categories.map((c) => _chip(c.$1, c.$2))])),
      Expanded(child: FutureBuilder<List<IslamicContent>>(
        future: _load(), builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return const Center(child: Text('তথ্য লোড করা যায়নি। আবার চেষ্টা করুন।'));
          final items = snapshot.data ?? [];
          if (items.isEmpty) return _emptyState();
          return ListView.separated(padding: const EdgeInsets.fromLTRB(16, 8, 16, 90), itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) => _contentCard(items[i]));
        },
      )),
    ]),
  );

  Widget _chip(String label, String? value) => Padding(padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 7),
    child: ChoiceChip(label: Text(label), selected: _category == value,
      onSelected: (_) => setState(() => _category = value), selectedColor: FatihaColors.mist));

  Widget _emptyState() => Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.menu_book_rounded, size: 48, color: FatihaColors.gold),
    const SizedBox(height: 12), Text(widget.favoritesOnly ? 'এখনো কোনো পছন্দের দোয়া নেই' : 'এখনো কোনো কন্টেন্ট যোগ করা হয়নি',
      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: FatihaColors.emerald)),
    const SizedBox(height: 8), const Text('যাচাই করা আরবি, বাংলা উচ্চারণ, অর্থ ও সূত্র যুক্ত হলে এখানে অফলাইনে পড়তে পারবেন।', textAlign: TextAlign.center,
      style: TextStyle(color: FatihaColors.muted)),
  ])));

  Widget _contentCard(IslamicContent item) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    Row(children: [Expanded(child: Text(item.titleBn, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: FatihaColors.emerald))),
      if (item.id != null) IconButton(tooltip: 'পছন্দে রাখুন', onPressed: () async { await _repo.setFavorite(item.id!, !item.isFavorite); setState(() {}); },
        icon: Icon(item.isFavorite ? Icons.bookmark : Icons.bookmark_border, color: FatihaColors.gold)),
      if (!widget.favoritesOnly) PopupMenuButton<String>(onSelected: (v) => v == 'edit' ? _edit(item: item) : _delete(item), itemBuilder: (_) => const [
        PopupMenuItem(value: 'edit', child: Text('সম্পাদনা')), PopupMenuItem(value: 'delete', child: Text('মুছুন'))]),
    ]),
    if (item.arabicText.isNotEmpty) Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Text(item.arabicText, textAlign: TextAlign.right, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 25, height: 1.8))),
    if (item.transliterationBn.isNotEmpty) Text('উচ্চারণ: ${item.transliterationBn}'),
    if (item.meaningBn.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text('অর্থ: ${item.meaningBn}')),
    if (item.sourceReference.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text('সূত্র: ${item.sourceReference}', style: const TextStyle(color: FatihaColors.muted, fontSize: 12))),
    if (item.authenticityNote.isNotEmpty) Text(item.authenticityNote, style: const TextStyle(fontSize: 12, color: FatihaColors.muted)),
    if (item.audioUrl.isNotEmpty || item.audioLocalPath.isNotEmpty) Align(alignment: Alignment.centerLeft, child: TextButton.icon(
      onPressed: () => _play(item), icon: Icon(_playingId == item.id ? Icons.graphic_eq : Icons.play_arrow), label: Text(_playingId == item.id ? 'অডিও চলছে' : 'অডিও শুনুন'))),
    if (item.audioLicenseNote.isNotEmpty) Text('অডিও অনুমতি/লাইসেন্স: ${item.audioLicenseNote}', style: const TextStyle(fontSize: 11, color: FatihaColors.muted)),
  ])));
}

class _ContentEditor extends StatefulWidget {
  const _ContentEditor({this.item});
  final IslamicContent? item;
  @override
  State<_ContentEditor> createState() => _ContentEditorState();
}

class _ContentEditorState extends State<_ContentEditor> {
  final _form = GlobalKey<FormState>();
  late final Map<String, TextEditingController> _c;
  @override
  void initState() {
    super.initState();
    final x = widget.item;
    _c = {
      'category': TextEditingController(text: x?.category ?? 'সকাল'),
      'title': TextEditingController(text: x?.titleBn ?? ''),
      'arabic': TextEditingController(text: x?.arabicText ?? ''),
      'translit': TextEditingController(text: x?.transliterationBn ?? ''),
      'meaning': TextEditingController(text: x?.meaningBn ?? ''),
      'source': TextEditingController(text: x?.sourceReference ?? ''),
      'auth': TextEditingController(text: x?.authenticityNote ?? ''),
      'url': TextEditingController(text: x?.audioUrl ?? ''),
      'path': TextEditingController(text: x?.audioLocalPath ?? ''),
      'license': TextEditingController(text: x?.audioLicenseNote ?? ''),
    };
  }
  @override
  void dispose() { for (final c in _c.values) { c.dispose(); } super.dispose(); }
  Widget _field(String key, String label, {int lines = 1, bool required = false}) => Padding(
    padding: const EdgeInsets.only(bottom: 10), child: TextFormField(controller: _c[key], maxLines: lines,
      validator: required ? (v) => v == null || v.trim().isEmpty ? 'এই ঘরটি পূরণ করুন' : null : null,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder())));

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.item == null ? 'নতুন দোয়া/আমল' : 'কন্টেন্ট সম্পাদনা'),
    content: SizedBox(width: 440, child: Form(key: _form, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
      _field('category', 'বিভাগ', required: true), _field('title', 'শিরোনাম', required: true),
      _field('arabic', 'আরবি', lines: 2), _field('translit', 'বাংলা উচ্চারণ', lines: 2),
      _field('meaning', 'বাংলা অর্থ', lines: 3), _field('source', 'সূত্র/রেফারেন্স'),
      _field('auth', 'যাচাই/বিশুদ্ধতা নোট', lines: 2),
      const Divider(), const Align(alignment: Alignment.centerLeft, child: Text('অডিও সেটিংস', style: TextStyle(fontWeight: FontWeight.bold))),
      _field('url', 'অডিও URL (ঐচ্ছিক)'), _field('path', 'ডিভাইসের অডিও ফাইল পাথ (ঐচ্ছিক)'),
      _field('license', 'অডিও ব্যবহারের অনুমতি/লাইসেন্স নোট'),
      const Text('ধর্মীয় লেখা প্রকাশের আগে নির্ভরযোগ্য উৎস দিয়ে যাচাই করুন।', style: TextStyle(fontSize: 12)),
    ])))),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('বাতিল')),
      FilledButton(onPressed: () {
        if (!_form.currentState!.validate()) return;
        String v(String k) => _c[k]!.text.trim();
        final old = widget.item;
        Navigator.pop(context, IslamicContent(id: old?.id, category: v('category'), titleBn: v('title'),
          arabicText: v('arabic'), transliterationBn: v('translit'), meaningBn: v('meaning'),
          sourceReference: v('source'), authenticityNote: v('auth'), isFavorite: old?.isFavorite ?? false,
          audioUrl: v('url'), audioLocalPath: v('path'), audioLicenseNote: v('license')));
      }, child: const Text('সংরক্ষণ'))],
  );
}
