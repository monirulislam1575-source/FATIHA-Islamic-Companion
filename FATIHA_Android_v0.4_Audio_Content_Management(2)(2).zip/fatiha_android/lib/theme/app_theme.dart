import 'package:flutter/material.dart';

/// Central brand palette. Change these values to reskin the whole app.
abstract final class FatihaColors {
  static const emerald = Color(0xFF174B3A);
  static const forest = Color(0xFF2D7658);
  static const gold = Color(0xFFC6A45A);
  static const ivory = Color(0xFFF7F5ED);
  static const mist = Color(0xFFE7EFE8);
  static const ink = Color(0xFF26342E);
  static const muted = Color(0xFF69756E);
  static const white = Color(0xFFFFFFFF);
}

abstract final class FatihaBrand {
  static const appName = 'FATIHA Islamic Companion';
  static const bengaliName = 'ফাতিহা';
  static const tagline = 'আল্লাহর স্মরণে, শান্তির পথে';
}

ThemeData buildFatihaTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: FatihaColors.emerald,
    brightness: Brightness.light,
    surface: FatihaColors.ivory,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme.copyWith(
      primary: FatihaColors.emerald,
      secondary: FatihaColors.gold,
      surface: FatihaColors.ivory,
    ),
    scaffoldBackgroundColor: FatihaColors.ivory,
    appBarTheme: const AppBarTheme(
      backgroundColor: FatihaColors.emerald,
      foregroundColor: FatihaColors.white,
      centerTitle: true,
      elevation: 0,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: FatihaColors.emerald,
      indicatorColor: FatihaColors.gold.withValues(alpha: 0.25),
      labelTextStyle: WidgetStateProperty.all(
        const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
      ),
    ),
    cardTheme: CardThemeData(
      color: FatihaColors.white,
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      margin: EdgeInsets.zero,
    ),
  );
}
