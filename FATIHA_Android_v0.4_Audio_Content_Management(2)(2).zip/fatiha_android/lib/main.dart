import 'package:flutter/material.dart';
import 'screens/app_shell.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const FatihaApp());
}

class FatihaApp extends StatelessWidget {
  const FatihaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: FatihaBrand.appName,
      debugShowCheckedModeBanner: false,
      theme: buildFatihaTheme(),
      home: const AppShell(),
    );
  }
}
